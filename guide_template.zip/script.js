//pesquisa csat
document.addEventListener('DOMContentLoaded', () => {
    const linkForm = 'https://pandorabrasil.zendesk.com/hc/pt-br/requests/new?ticket_form_id=27014006985235';
  	const NPSLink = 'https://pandorabrasil.zendesk.com/hc/pt-br/requests/new?ticket_form_id=27017620445971';
    const urlAtual = window.location.href;

    if (urlAtual.startsWith(linkForm)) {
      	runCsatScript();
    } else if (urlAtual.startsWith(NPSLink)) {
				runNpsScript();
    }	
});

function runCsatScript () {

	  const form = document.querySelector('.request-form')
    const questionLength = (form.length) - 9
    const labels = document.querySelectorAll('#new_request div:nth-child(n+8) label')
    const selectedLengths = [0, 0, 0, 0];

    for (let i = 0; i < questionLength; i++) {
      
        const question = document.createElement('div');
        question.className = `question-container question${i}`;
        const titleQuestion = document.createElement('h2');
        titleQuestion.innerText = labels[i].innerText;
        question.appendChild(titleQuestion);

        //stars
        const stars = document.createElement('div');
        stars.className = 'stars-content';
        question.appendChild(stars);
      
        //index
        const iconsContainer = document.createElement('div')
        iconsContainer.classList.add('icons-container')
        question.appendChild(iconsContainer)

        const titleField = titleQuestion.innerText.trim();
        const regexIcon = /\((NPS|\d+)\)/; // Expressão regular para encontrar "(NPS)" ou qualquer número entre parênteses

        const match = titleField.match(regexIcon);
        let iconsLength = match ? parseInt(match[1]) : 5; // Se houver uma correspondência, obtém o número de ícones, senão, define como 5

        if (match && match[1] === 'NPS') {
            const textWithoutTag = titleField.replace(match[0], `<span class='nps-tag'>${match[0]}</span>`);
            titleQuestion.innerHTML = textWithoutTag;
        }
      
        let originalTitle = titleQuestion.innerText.trim();
        let imgSource = 'https://theme.zdassets.com/theme_assets/9040643/27d84619055ec470b95ceb70de56112a1639bd37.png';

        const regexStar = /\*/;
        if (originalTitle.startsWith("*")) {
            titleQuestion.innerHTML = originalTitle.replace(regexStar, '<span class="styled-number">*</span>');
            imgSource = 'https://theme.zdassets.com/theme_assets/9040643/3ce386aa9d142d5a7f54596d24f9fa41de13dab5.png';
        }

        const regexNumber = /\((\d+)\)/;
        const matchNumber = originalTitle.match(regexNumber);
        if (matchNumber) {
            titleQuestion.innerHTML = titleQuestion.innerHTML.replace(regexNumber, `<span class="styled-number">$&</span>`);
        }

        const regexHeart = /S2/;
        if (originalTitle.startsWith("S2")) {
            titleQuestion.innerHTML = originalTitle.replace(regexHeart, '<span class="styled-number">S2</span>');
            imgSource = 'https://cdn.iconscout.com/icon/free/png-256/free-heart-1161-457786.png';
        }

        for (let j = 0; j < iconsLength; j++) {
            const star = document.createElement('img');
            star.src = imgSource;
            star.className = `star-icon icon${j}`;
            star.addEventListener('click', () => { handleClick(star, j, i); });
            stars.appendChild(star);
        }
      
        for (let i = 0; i < iconsLength; i++) {
            const iconsIndex = document.createElement('p');
            iconsIndex.classList.add('icon-index');
            iconsIndex.innerHTML = i + 1;
            iconsContainer.appendChild(iconsIndex)
        };
      
        form.appendChild(question);

        //criando botão de submit
        if ((i + 1) === questionLength) {
            const submitBtn = document.createElement('input')
            submitBtn.setAttribute("type", "submit")
            submitBtn.setAttribute("name", "commit")
            submitBtn.setAttribute("value", "Enviar")
            submitBtn.classList.add('submit-btn')

            form.appendChild(submitBtn)
        }

        // Removendo botão tradicional
        const currentSubmitBtn = document.querySelector('#new_request footer');
        currentSubmitBtn.style.display = 'none'; 

        // Iterando sobre os títulos
        document.querySelectorAll('h2').forEach(title => {
          	const txtContent = title.innerText;
						const regexText = /\(TXT\)/;
          
            if (regexText.test(title.innerText)) {
                const questionWithTextArea = title.parentNode;

                // Ocultando conteúdo de estrelas
                questionWithTextArea.querySelectorAll('.stars-content').forEach(content => {
                    content.style.display = 'none';
                });

                // Ocultando o container de ícones
                const iconsContainer = questionWithTextArea.querySelector('.icons-container');
                if (iconsContainer) {
                    iconsContainer.style.display = 'none';
                }
              
                // Adicionando span em torno de (TXT)
                const newText = title.innerText.replace(regexText, "<span class='nps-tag'>$&</span>");
                title.innerHTML = newText;

                // Criando e adicionando uma área de texto
                const newTextarea = document.createElement('textarea');
                newTextarea.classList.add('multilinha');
                questionWithTextArea.appendChild(newTextarea);
            }
        });

        const formZendeskFields = document.querySelectorAll('.form-field')
        const zendeskFields = Array.from(formZendeskFields)
        let zendeskFieldsFilter = zendeskFields.slice(5)
        zendeskFieldsFilter.pop()

        zendeskFieldsFilter.forEach((field) => {
            const index = zendeskFieldsFilter.indexOf(field)
            field.classList.add(`question${index}`)
        })

        const textareaFields = document.querySelectorAll('.multilinha')
        textareaFields.forEach((field) => {

            const classQuestion = field.parentNode.classList[1]; 
            const indexQuestion = classQuestion[classQuestion.length - 1]

            field.addEventListener('input', () => {
                if (classQuestion === zendeskFieldsFilter[indexQuestion].classList[4]) {
                    zendeskFieldsFilter[indexQuestion].querySelector('input').value = field.value; 
                    field.classList.remove('.delete-field')
                }
            })
        })
    }
  
    const apiUrl = 'https://pandorabrasil.zendesk.com/api/v2/ticket_forms'
    const campos = [];
    async function getFields() {
        const res = await fetch(apiUrl)
        const data = await res.json()
        const csatForm = data.ticket_forms.filter(form => form.name === 'Pesquisa de Csat')
        const IDs = csatForm[0].ticket_field_ids.slice(3)

        for (let f = 0; f < IDs.length; f++) {
            const el = document.querySelector(`.request_custom_fields_${IDs[f]}`)
            if (el.classList.contains('string')) {
                campos.push(document.querySelector(`.request_custom_fields_${IDs[f]} input`))
            } else if (el.classList.contains('text')) {
                campos.push(document.querySelector(`.request_custom_fields_${IDs[f]} textarea`))
            }
        }
    }
    getFields()
  
      function handleClick(star, index, questionIndex) {
        const allStars = star.parentNode.querySelectorAll('.star-icon');

        selectedLengths[questionIndex] = index + 1;

        for (let i = 0; i < allStars.length; i++) {
            if (i <= index) {
                allStars[i].classList.add('selected');
            } else {
                allStars[i].classList.remove('selected');
            }
        }

        campos[questionIndex].value = selectedLengths[questionIndex];
    }
  
    const fields = document.querySelectorAll('.form-field')
    fields.forEach((item) => {
        item.classList.add('delete-field')
    })
  
    const formContainer = document.querySelector('.form'); 
    formContainer.classList.add('form-container');
  
    const formTitle = document.querySelector('.container h1')
    formTitle.classList.add('form-title')
    formTitle.innerHTML = 'Avalie o nosso atendimento'; 

    //envio de form com dados incompletos
    const emailField = document.querySelector('#request_anonymous_requester_email').value
    const ticketIDField = document.querySelector('#request_custom_fields_27062271901843').value

    const customerUrl = `${linkForm}&tf_subject=Pesquisa%20de%20Csat&tf_description=Pesquisa%20de%20Csat&tf_anonymous_requester_email=${emailField}&tf_27062271901843=${ticketIDField}`;

    if (urlAtual.startsWith(linkForm)) {

        const submitBtn = document.querySelector('.submit-btn')
        submitBtn.addEventListener('click', () => {

            const formInputs = document.querySelectorAll('.form-field input');
            formInputs.forEach((input) => {

                if (input.value === '' && input.parentNode.classList.contains('required')) {
                    alert("Preencha o formulário completamente.");
                    setTimeout(() => {
                        window.location.assign(customerUrl)
                    }, 100)
                }
            })
        })
    }
  
}

//corrigindo erro em casos de campos vazios
if (window.location.href.startsWith('https://pandorabrasil.zendesk.com/hc/pt-br/requests/new?ticket_form_id=27014006985235')) {
    document.addEventListener('DOMContentLoaded', () => {
        const form = document.querySelector('form[data-form][data-form-type="request"]')
        if (form) {
            const submitBtns = form.querySelectorAll('[type="submit"]')
            submitBtns.forEach(button => {
                button.addEventListener('click', (e) => {
                    const question1 = document.querySelector("#request_custom_fields_27013747992211");
                    const question2 = document.querySelector('#request_custom_fields_27013838905235');
                    const question3 = document.querySelector("#request_custom_fields_27013829679507");

                    if (question1.value === '' || question2.value === '' || question3.value === '') {
                        e.preventDefault();
                        alert('Responda todas as perguntas para enviarmos o formulário.');
                        return
                    }

                    form.submit();
                })
            })
        }
    })
}

//formulário de NPS

function runNpsScript () {

    const form = document.querySelector('.request-form')
    const questionLength = (form.length) - 9
    const labels = document.querySelectorAll('#new_request div:nth-child(n+8) label')
    const selectedLengths = [0, 0, 0, 0];

    for(let i=0;i<questionLength;i++) {

        const question = document.createElement('div')
        question.className = `question-container question${i}`;
        const titleQuestion = document.createElement('h2')
        titleQuestion.innerText = labels[i].innerText; 
        question.appendChild(titleQuestion)

        //icons
        const icons = document.createElement('div');
        icons.className = 'stars-content';
      	icons.classList.add('nps-icons')
        question.appendChild(icons);

        form.appendChild(question)

        const titleField = titleQuestion.innerText.trim()
        const regexNPS = new RegExp("\\(" + "(NPS)" + "\\)")
        const regexTXT = new RegExp("\\(" + "(TXT)" + "\\)");
        let iconsLength = 0;

        if (regexNPS.test(titleField)) {
            iconsLength = 11;
            const textWithoutTagNPS = titleField.replace(regexNPS, `<span class='nps-tag'>$&</span>`)
            titleQuestion.innerHTML = textWithoutTagNPS;
        }else {
            iconsLength = 0;
        }

        if (regexTXT.test(titleField)) {
            const textWithoutTagTXT = titleField.replace(regexTXT, `<span class='nps-tag'>$&</span>`)
            titleQuestion.innerHTML = textWithoutTagTXT;
        }
    
        for (let icon = 0;icon < iconsLength;icon++) {
            const box = document.createElement('div');
            box.classList.add('box')
          
          	box.addEventListener('click', () => { handleClick(box, icon, i) });
          
            const boxIndex = document.createElement('p');
            boxIndex.innerHTML = icon;
          	box.appendChild(boxIndex)
            icons.appendChild(box)
        }
      
      	
      	//definindo campo multilinha
        const h2Textearea = document.querySelectorAll('h2')

        h2Textearea.forEach((txt) => {
            if (regexTXT.test(txt.innerText)) {
                const questionWithTextArea = txt.parentNode
                const boxContent = questionWithTextArea.querySelectorAll('.stars-content')
                boxContent.forEach((content) => {
                    content.style.display = 'none';
                })
                const newTextarea = document.createElement('textarea')
                newTextarea.classList.add('multilinha')
                questionWithTextArea.appendChild(newTextarea)
            }
        })
      
        const formZendeskFields = document.querySelectorAll('.form-field')
        const zendeskFields = Array.from(formZendeskFields)
        const zendeskfieldsFilter = zendeskFields.slice(5)
        zendeskfieldsFilter.pop()
      
        zendeskfieldsFilter.forEach((field) => {
            const index = zendeskfieldsFilter.indexOf(field)
            field.classList.add(`question${index}`)
        })
      
        const textareaFields = document.querySelectorAll('.multilinha');
        textareaFields.forEach((field) => {
						const classQuestion = field.parentNode.classList[1]
            const indexQuestion = classQuestion[classQuestion.length - 1]

            field.addEventListener('input', () => {
                if (zendeskfieldsFilter[indexQuestion].classList[4] === classQuestion) {
                    zendeskfieldsFilter[indexQuestion].querySelector('input').value = field.value;
                  	field.classList.remove('.delete-field')
                }
            })
        })
      
          if ((i + 1) === questionLength) {
            const submitBtn = document.createElement('input')
            submitBtn.setAttribute("type", "submit")
            submitBtn.setAttribute("name", "commit")
            submitBtn.setAttribute("value", "Enviar")
            submitBtn.classList.add('submit-btn')

            form.appendChild(submitBtn)
        }
    }
  
  	const apiUrl = 'https://pandorabrasil.zendesk.com/api/v2/ticket_forms'
    const campos = [];
    async function getFields() {
        const res = await fetch(apiUrl)
        const data = await res.json()
        const csatForm = data.ticket_forms.filter(form => form.name === 'Pesquisa de NPS')
        const IDs = csatForm[0].ticket_field_ids.slice(3)

        for (let f = 0; f < IDs.length; f++) {
            const el = document.querySelector(`.request_custom_fields_${IDs[f]}`)
            if (el.classList.contains('string')) {
                campos.push(document.querySelector(`.request_custom_fields_${IDs[f]} input`))
            } else if (el.classList.contains('text')) {
                campos.push(document.querySelector(`.request_custom_fields_${IDs[f]} textarea`))
            }
        }
    }
    getFields()
  
      function handleClick(star, index, questionIndex) {
        const allStars = star.parentNode.querySelectorAll('.box');

        selectedLengths[questionIndex] = index;

        for (let i = 0; i < allStars.length; i++) {
            if (i <= index) {
                allStars[i].classList.add('selected-box');
            } else {
                allStars[i].classList.remove('selected-box');
            }
        }
        campos[questionIndex].value = selectedLengths[questionIndex];
    }

  	const fields = document.querySelectorAll('.form-field')
    fields.forEach((item) => {
        item.classList.add('delete-field')
    })
  
    //removendo botão tradicional
    const currentSubmitBtn = document.querySelector('#new_request footer')
    currentSubmitBtn.style.display = 'none';
  
    const formContainer = document.querySelector('.form');
    formContainer.classList.add('form-container');
  
    //editando título do form
    const formTitle = document.querySelector('.container h1')
    formTitle.classList.add('form-title')
    formTitle.innerHTML = 'Avalie o nosso atendimento';
  
  	//envio de form com dados incompletos
    const emailField = document.querySelector('#request_anonymous_requester_email').value
    const ticketIDField = document.querySelector('#request_custom_fields_27062271901843').value
    const customerUrlNPS = `${NPSLink}&tf_subject=Pesquisa%20de%20Csat&tf_description=Pesquisa%20de%20Csat&tf_anonymous_requester_email=${emailField}&tf_27062271901843=${ticketIDField}`;

    if (urlAtual.startsWith(NPSLink)) {

        const submitBtn = document.querySelector('.submit-btn')
        submitBtn.addEventListener('click', () => {

            const formInputs = document.querySelectorAll('.form-field input');
            formInputs.forEach((input) => {

                if (input.value === '' && input.parentNode.classList.contains('required')) {
                    alert("Preencha o formulário completamente.");
                    setTimeout(() => {
                        window.location.assign(customerUrlNPS)
                    }, 100)
                }
            })
        })
    }
}

//prevenindo envio de form com campo de nps vazio
if (window.location.href.startsWith('https://pandorabrasil.zendesk.com/hc/pt-br/requests/new?ticket_form_id=27017620445971')) {
    document.addEventListener('DOMContentLoaded', () => {
        const form = document.querySelector('form[data-form][data-form-type="request"]')
        if (form) {
            const submitBtns = form.querySelectorAll('[type="submit"]');
            submitBtns.forEach(button => {
                button.addEventListener('click', (e) => {
                    e.preventDefault();
                    
                    const npsField = document.querySelector('#request_custom_fields_27013901191955');
                    if (npsField.value === '') {
                        e.preventDefault();
                        alert('Dê uma nota de 0 a 10 para que o formulário seja enviado.')
                    } else{
                        form.submit();
                    }
                })
            })
        }
    })
}



(function () {
  'use strict';

  // Key map
  const ENTER = 13;
  const ESCAPE = 27;

  function toggleNavigation(toggle, menu) {
    const isExpanded = menu.getAttribute("aria-expanded") === "true";
    menu.setAttribute("aria-expanded", !isExpanded);
    toggle.setAttribute("aria-expanded", !isExpanded);
  }

  function closeNavigation(toggle, menu) {
    menu.setAttribute("aria-expanded", false);
    toggle.setAttribute("aria-expanded", false);
    toggle.focus();
  }

  // Navigation

  window.addEventListener("DOMContentLoaded", () => {
    const menuButton = document.querySelector(".header .menu-button-mobile");
    const menuList = document.querySelector("#user-nav-mobile");

    menuButton.addEventListener("click", (event) => {
      event.stopPropagation();
      toggleNavigation(menuButton, menuList);
    });

    menuList.addEventListener("keyup", (event) => {
      if (event.keyCode === ESCAPE) {
        event.stopPropagation();
        closeNavigation(menuButton, menuList);
      }
    });

    // Toggles expanded aria to collapsible elements
    const collapsible = document.querySelectorAll(
      ".collapsible-nav, .collapsible-sidebar"
    );

    collapsible.forEach((element) => {
      const toggle = element.querySelector(
        ".collapsible-nav-toggle, .collapsible-sidebar-toggle"
      );

      element.addEventListener("click", () => {
        toggleNavigation(toggle, element);
      });

      element.addEventListener("keyup", (event) => {
        console.log("escape");
        if (event.keyCode === ESCAPE) {
          closeNavigation(toggle, element);
        }
      });
    });

    // If multibrand search has more than 5 help centers or categories collapse the list
    const multibrandFilterLists = document.querySelectorAll(
      ".multibrand-filter-list"
    );
    multibrandFilterLists.forEach((filter) => {
      if (filter.children.length > 6) {
        // Display the show more button
        const trigger = filter.querySelector(".see-all-filters");
        trigger.setAttribute("aria-hidden", false);

        // Add event handler for click
        trigger.addEventListener("click", (event) => {
          event.stopPropagation();
          trigger.parentNode.removeChild(trigger);
          filter.classList.remove("multibrand-filter-list--collapsed");
        });
      }
    });
  });

  const isPrintableChar = (str) => {
    return str.length === 1 && str.match(/^\S$/);
  };

  function Dropdown(toggle, menu) {
    this.toggle = toggle;
    this.menu = menu;

    this.menuPlacement = {
      top: menu.classList.contains("dropdown-menu-top"),
      end: menu.classList.contains("dropdown-menu-end"),
    };

    this.toggle.addEventListener("click", this.clickHandler.bind(this));
    this.toggle.addEventListener("keydown", this.toggleKeyHandler.bind(this));
    this.menu.addEventListener("keydown", this.menuKeyHandler.bind(this));
    document.body.addEventListener("click", this.outsideClickHandler.bind(this));

    const toggleId = this.toggle.getAttribute("id") || crypto.randomUUID();
    const menuId = this.menu.getAttribute("id") || crypto.randomUUID();

    this.toggle.setAttribute("id", toggleId);
    this.menu.setAttribute("id", menuId);

    this.toggle.setAttribute("aria-controls", menuId);
    this.menu.setAttribute("aria-labelledby", toggleId);

    this.menu.setAttribute("tabindex", -1);
    this.menuItems.forEach((menuItem) => {
      menuItem.tabIndex = -1;
    });

    this.focusedIndex = -1;
  }

  Dropdown.prototype = {
    get isExpanded() {
      return this.toggle.getAttribute("aria-expanded") === "true";
    },

    get menuItems() {
      return Array.prototype.slice.call(
        this.menu.querySelectorAll("[role='menuitem'], [role='menuitemradio']")
      );
    },

    dismiss: function () {
      if (!this.isExpanded) return;

      this.toggle.removeAttribute("aria-expanded");
      this.menu.classList.remove("dropdown-menu-end", "dropdown-menu-top");
      this.focusedIndex = -1;
    },

    open: function () {
      if (this.isExpanded) return;

      this.toggle.setAttribute("aria-expanded", true);
      this.handleOverflow();
    },

    handleOverflow: function () {
      var rect = this.menu.getBoundingClientRect();

      var overflow = {
        right: rect.left < 0 || rect.left + rect.width > window.innerWidth,
        bottom: rect.top < 0 || rect.top + rect.height > window.innerHeight,
      };

      if (overflow.right || this.menuPlacement.end) {
        this.menu.classList.add("dropdown-menu-end");
      }

      if (overflow.bottom || this.menuPlacement.top) {
        this.menu.classList.add("dropdown-menu-top");
      }

      if (this.menu.getBoundingClientRect().top < 0) {
        this.menu.classList.remove("dropdown-menu-top");
      }
    },

    focusByIndex: function (index) {
      if (!this.menuItems.length) return;

      this.menuItems.forEach((item, itemIndex) => {
        if (itemIndex === index) {
          item.tabIndex = 0;
          item.focus();
        } else {
          item.tabIndex = -1;
        }
      });

      this.focusedIndex = index;
    },

    focusFirstMenuItem: function () {
      this.focusByIndex(0);
    },

    focusLastMenuItem: function () {
      this.focusByIndex(this.menuItems.length - 1);
    },

    focusNextMenuItem: function (currentItem) {
      if (!this.menuItems.length) return;

      const currentIndex = this.menuItems.indexOf(currentItem);
      const nextIndex = (currentIndex + 1) % this.menuItems.length;

      this.focusByIndex(nextIndex);
    },

    focusPreviousMenuItem: function (currentItem) {
      if (!this.menuItems.length) return;

      const currentIndex = this.menuItems.indexOf(currentItem);
      const previousIndex =
        currentIndex <= 0 ? this.menuItems.length - 1 : currentIndex - 1;

      this.focusByIndex(previousIndex);
    },

    focusByChar: function (currentItem, char) {
      char = char.toLowerCase();

      const itemChars = this.menuItems.map((menuItem) =>
        menuItem.textContent.trim()[0].toLowerCase()
      );

      const startIndex =
        (this.menuItems.indexOf(currentItem) + 1) % this.menuItems.length;

      // look up starting from current index
      let index = itemChars.indexOf(char, startIndex);

      // if not found, start from start
      if (index === -1) {
        index = itemChars.indexOf(char, 0);
      }

      if (index > -1) {
        this.focusByIndex(index);
      }
    },

    outsideClickHandler: function (e) {
      if (
        this.isExpanded &&
        !this.toggle.contains(e.target) &&
        !e.composedPath().includes(this.menu)
      ) {
        this.dismiss();
        this.toggle.focus();
      }
    },

    clickHandler: function (event) {
      event.stopPropagation();
      event.preventDefault();

      if (this.isExpanded) {
        this.dismiss();
        this.toggle.focus();
      } else {
        this.open();
        this.focusFirstMenuItem();
      }
    },

    toggleKeyHandler: function (e) {
      const key = e.key;

      switch (key) {
        case "Enter":
        case " ":
        case "ArrowDown":
        case "Down": {
          e.stopPropagation();
          e.preventDefault();

          this.open();
          this.focusFirstMenuItem();
          break;
        }
        case "ArrowUp":
        case "Up": {
          e.stopPropagation();
          e.preventDefault();

          this.open();
          this.focusLastMenuItem();
          break;
        }
        case "Esc":
        case "Escape": {
          e.stopPropagation();
          e.preventDefault();

          this.dismiss();
          this.toggle.focus();
          break;
        }
      }
    },

    menuKeyHandler: function (e) {
      const key = e.key;
      const currentElement = this.menuItems[this.focusedIndex];

      if (e.ctrlKey || e.altKey || e.metaKey) {
        return;
      }

      switch (key) {
        case "Esc":
        case "Escape": {
          e.stopPropagation();
          e.preventDefault();

          this.dismiss();
          this.toggle.focus();
          break;
        }
        case "ArrowDown":
        case "Down": {
          e.stopPropagation();
          e.preventDefault();

          this.focusNextMenuItem(currentElement);
          break;
        }
        case "ArrowUp":
        case "Up": {
          e.stopPropagation();
          e.preventDefault();
          this.focusPreviousMenuItem(currentElement);
          break;
        }
        case "Home":
        case "PageUp": {
          e.stopPropagation();
          e.preventDefault();
          this.focusFirstMenuItem();
          break;
        }
        case "End":
        case "PageDown": {
          e.stopPropagation();
          e.preventDefault();
          this.focusLastMenuItem();
          break;
        }
        case "Tab": {
          if (e.shiftKey) {
            e.stopPropagation();
            e.preventDefault();
            this.dismiss();
            this.toggle.focus();
          } else {
            this.dismiss();
          }
          break;
        }
        default: {
          if (isPrintableChar(key)) {
            e.stopPropagation();
            e.preventDefault();
            this.focusByChar(currentElement, key);
          }
        }
      }
    },
  };

  // Drodowns

  window.addEventListener("DOMContentLoaded", () => {
    const dropdowns = [];
    const dropdownToggles = document.querySelectorAll(".dropdown-toggle");

    dropdownToggles.forEach((toggle) => {
      const menu = toggle.nextElementSibling;
      if (menu && menu.classList.contains("dropdown-menu")) {
        dropdowns.push(new Dropdown(toggle, menu));
      }
    });
  });

  // Share

  window.addEventListener("DOMContentLoaded", () => {
    const links = document.querySelectorAll(".share a");
    links.forEach((anchor) => {
      anchor.addEventListener("click", (event) => {
        event.preventDefault();
        window.open(anchor.href, "", "height = 500, width = 500");
      });
    });
  });

  // Vanilla JS debounce function, by Josh W. Comeau:
  // https://www.joshwcomeau.com/snippets/javascript/debounce/
  function debounce(callback, wait) {
    let timeoutId = null;
    return (...args) => {
      window.clearTimeout(timeoutId);
      timeoutId = window.setTimeout(() => {
        callback.apply(null, args);
      }, wait);
    };
  }

  // Define variables for search field
  let searchFormFilledClassName = "search-has-value";
  let searchFormSelector = "form[role='search']";

  // Clear the search input, and then return focus to it
  function clearSearchInput(event) {
    event.target
      .closest(searchFormSelector)
      .classList.remove(searchFormFilledClassName);

    let input;
    if (event.target.tagName === "INPUT") {
      input = event.target;
    } else if (event.target.tagName === "BUTTON") {
      input = event.target.previousElementSibling;
    } else {
      input = event.target.closest("button").previousElementSibling;
    }
    input.value = "";
    input.focus();
  }

  // Have the search input and clear button respond
  // when someone presses the escape key, per:
  // https://twitter.com/adambsilver/status/1152452833234554880
  function clearSearchInputOnKeypress(event) {
    const searchInputDeleteKeys = ["Delete", "Escape"];
    if (searchInputDeleteKeys.includes(event.key)) {
      clearSearchInput(event);
    }
  }

  // Create an HTML button that all users -- especially keyboard users --
  // can interact with, to clear the search input.
  // To learn more about this, see:
  // https://adrianroselli.com/2019/07/ignore-typesearch.html#Delete
  // https://www.scottohara.me/blog/2022/02/19/custom-clear-buttons.html
  function buildClearSearchButton(inputId) {
    const button = document.createElement("button");
    button.setAttribute("type", "button");
    button.setAttribute("aria-controls", inputId);
    button.classList.add("clear-button");
    const buttonLabel = window.searchClearButtonLabelLocalized;
    const icon = `<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' focusable='false' role='img' viewBox='0 0 12 12' aria-label='${buttonLabel}'><path stroke='currentColor' stroke-linecap='round' stroke-width='2' d='M3 9l6-6m0 6L3 3'/></svg>`;
    button.innerHTML = icon;
    button.addEventListener("click", clearSearchInput);
    button.addEventListener("keyup", clearSearchInputOnKeypress);
    return button;
  }

  // Append the clear button to the search form
  function appendClearSearchButton(input, form) {
    const searchClearButton = buildClearSearchButton(input.id);
    form.append(searchClearButton);
    if (input.value.length > 0) {
      form.classList.add(searchFormFilledClassName);
    }
  }

  // Add a class to the search form when the input has a value;
  // Remove that class from the search form when the input doesn't have a value.
  // Do this on a delay, rather than on every keystroke.
  const toggleClearSearchButtonAvailability = debounce((event) => {
    const form = event.target.closest(searchFormSelector);
    form.classList.toggle(
      searchFormFilledClassName,
      event.target.value.length > 0
    );
  }, 200);

  // Search

  window.addEventListener("DOMContentLoaded", () => {
    // Set up clear functionality for the search field
    const searchForms = [...document.querySelectorAll(searchFormSelector)];
    const searchInputs = searchForms.map((form) =>
      form.querySelector("input[type='search']")
    );
    searchInputs.forEach((input) => {
      appendClearSearchButton(input, input.closest(searchFormSelector));
      input.addEventListener("keyup", clearSearchInputOnKeypress);
      input.addEventListener("keyup", toggleClearSearchButtonAvailability);
    });
  });

  const key = "returnFocusTo";

  function saveFocus() {
    const activeElementId = document.activeElement.getAttribute("id");
    sessionStorage.setItem(key, "#" + activeElementId);
  }

  function returnFocus() {
    const returnFocusTo = sessionStorage.getItem(key);
    if (returnFocusTo) {
      sessionStorage.removeItem("returnFocusTo");
      const returnFocusToEl = document.querySelector(returnFocusTo);
      returnFocusToEl && returnFocusToEl.focus && returnFocusToEl.focus();
    }
  }

  // Forms

  window.addEventListener("DOMContentLoaded", () => {
    // In some cases we should preserve focus after page reload
    returnFocus();

    // show form controls when the textarea receives focus or back button is used and value exists
    const commentContainerTextarea = document.querySelector(
      ".comment-container textarea"
    );
    const commentContainerFormControls = document.querySelector(
      ".comment-form-controls, .comment-ccs"
    );

    if (commentContainerTextarea) {
      commentContainerTextarea.addEventListener(
        "focus",
        function focusCommentContainerTextarea() {
          commentContainerFormControls.style.display = "block";
          commentContainerTextarea.removeEventListener(
            "focus",
            focusCommentContainerTextarea
          );
        }
      );

      if (commentContainerTextarea.value !== "") {
        commentContainerFormControls.style.display = "block";
      }
    }

    // Expand Request comment form when Add to conversation is clicked
    const showRequestCommentContainerTrigger = document.querySelector(
      ".request-container .comment-container .comment-show-container"
    );
    const requestCommentFields = document.querySelectorAll(
      ".request-container .comment-container .comment-fields"
    );
    const requestCommentSubmit = document.querySelector(
      ".request-container .comment-container .request-submit-comment"
    );

    if (showRequestCommentContainerTrigger) {
      showRequestCommentContainerTrigger.addEventListener("click", () => {
        showRequestCommentContainerTrigger.style.display = "none";
        Array.prototype.forEach.call(requestCommentFields, (element) => {
          element.style.display = "block";
        });
        requestCommentSubmit.style.display = "inline-block";

        if (commentContainerTextarea) {
          commentContainerTextarea.focus();
        }
      });
    }

    // Mark as solved button
    const requestMarkAsSolvedButton = document.querySelector(
      ".request-container .mark-as-solved:not([data-disabled])"
    );
    const requestMarkAsSolvedCheckbox = document.querySelector(
      ".request-container .comment-container input[type=checkbox]"
    );
    const requestCommentSubmitButton = document.querySelector(
      ".request-container .comment-container input[type=submit]"
    );

    if (requestMarkAsSolvedButton) {
      requestMarkAsSolvedButton.addEventListener("click", () => {
        requestMarkAsSolvedCheckbox.setAttribute("checked", true);
        requestCommentSubmitButton.disabled = true;
        requestMarkAsSolvedButton.setAttribute("data-disabled", true);
        requestMarkAsSolvedButton.form.submit();
      });
    }

    // Change Mark as solved text according to whether comment is filled
    const requestCommentTextarea = document.querySelector(
      ".request-container .comment-container textarea"
    );

    const usesWysiwyg =
      requestCommentTextarea &&
      requestCommentTextarea.dataset.helper === "wysiwyg";

    function isEmptyPlaintext(s) {
      return s.trim() === "";
    }

    function isEmptyHtml(xml) {
      const doc = new DOMParser().parseFromString(`<_>${xml}</_>`, "text/xml");
      const img = doc.querySelector("img");
      return img === null && isEmptyPlaintext(doc.children[0].textContent);
    }

    const isEmpty = usesWysiwyg ? isEmptyHtml : isEmptyPlaintext;

    if (requestCommentTextarea) {
      requestCommentTextarea.addEventListener("input", () => {
        if (isEmpty(requestCommentTextarea.value)) {
          if (requestMarkAsSolvedButton) {
            requestMarkAsSolvedButton.innerText =
              requestMarkAsSolvedButton.getAttribute("data-solve-translation");
          }
        } else {
          if (requestMarkAsSolvedButton) {
            requestMarkAsSolvedButton.innerText =
              requestMarkAsSolvedButton.getAttribute(
                "data-solve-and-submit-translation"
              );
          }
        }
      });
    }

    const selects = document.querySelectorAll(
      "#request-status-select, #request-organization-select"
    );

    selects.forEach((element) => {
      element.addEventListener("change", (event) => {
        event.stopPropagation();
        saveFocus();
        element.form.submit();
      });
    });

    // Submit requests filter form on search in the request list page
    const quickSearch = document.querySelector("#quick-search");
    if (quickSearch) {
      quickSearch.addEventListener("keyup", (event) => {
        if (event.keyCode === ENTER) {
          event.stopPropagation();
          saveFocus();
          quickSearch.form.submit();
        }
      });
    }

    // Submit organization form in the request page
    const requestOrganisationSelect = document.querySelector(
      "#request-organization select"
    );

    if (requestOrganisationSelect) {
      requestOrganisationSelect.addEventListener("change", () => {
        requestOrganisationSelect.form.submit();
      });

      requestOrganisationSelect.addEventListener("click", (e) => {
        // Prevents Ticket details collapsible-sidebar to close on mobile
        e.stopPropagation();
      });
    }

    // If there are any error notifications below an input field, focus that field
    const notificationElm = document.querySelector(".notification-error");
    if (
      notificationElm &&
      notificationElm.previousElementSibling &&
      typeof notificationElm.previousElementSibling.focus === "function"
    ) {
      notificationElm.previousElementSibling.focus();
    }
  });

})();


const headerContainer = document.querySelector('.header-container');
const logo = document.querySelector('.logo img');

if (window.location.href === 'https://pandorabrasil.zendesk.com/hc/pt-br') {
    headerContainer.style.position = 'fixed';

    window.addEventListener('scroll', () => {
        const topWindow = window.scrollY
        
        if (topWindow >= 30) {

            if (window.innerWidth <= 450) {
                logo.style.filter = 'invert(0)'
            }

            headerContainer.style.backgroundColor = 'rgb(255, 249, 251)'
        }else{
            headerContainer.style.backgroundColor = 'transparent';
        }
    })
  
    window.addEventListener('scroll', () => {

        const topWindow = window.scrollY;

        if (topWindow === 0 && window.innerWidth <= 450) {
            logo.style.filter = 'invert(100%)';
        }else{
            logo.style.filter = 'invert(0)';
        }

    })
}




if (window.location.href === 'https://pandorabrasil.zendesk.com/hc/pt-br') {

    //rederizando adicionados recentemente
    const apiUrl = 'https://pandorabrasil.zendesk.com/api/v2/help_center/articles'; 

    const recentDates = []; 
    const content = document.querySelector('.content')
    const dynamicContent = document.querySelector('.dynamic-content')
    const dynamicTitle = document.querySelector('.dynamic-content h1')

    //btns
    const frequentlyTopicsBtn = document.querySelector('.dynamic-btns button:nth-of-type(1)')
    const ourJewelArticles = document.querySelector('.dynamic-btns button:nth-of-type(2)')
    const regulationsArticles = document.querySelector('.dynamic-btns button:nth-of-type(3)')
    const openTicketBtn = document.querySelector('.dynamic-btns button:nth-of-type(4)')

    async function getArticles () {

        const res = await fetch(apiUrl)
        const data = await res.json()
        const articles = data.articles; 

        function returnDateFormat (dateString) {
            return new Date(dateString)
        }

        articles.sort((a, b) => {
            const date1 = returnDateFormat(a.created_at)
            const date2 = returnDateFormat(b.created_at)
            return date2 - date1; 
        })

        const frequentArticles = articles.sort((a, b) => {
            const voted1 = a.vote_count;
            const voted2 = b.vote_count;
            return voted2 - voted1;
        })
        const firstTenArticles = frequentArticles.slice(0, 10).reverse()

        articles.map(article => {
            recentDates.push(article.created_at); 

            for (let i = 0;i < 10; i++) {
                if (article.created_at === recentDates[i]) {
                    let articlesLinks = `
                        <p><a href=${article.html_url}>${article.title}</a></p>
                    `;
                      content.insertAdjacentHTML('afterbegin', articlesLinks)
                }
            }

            frequentlyTopicsBtn.addEventListener('click', () => {
                dynamicContent.classList.add('change-content')

                setTimeout(() => {
                    content.innerHTML = '';
                    firstTenArticles.map(article => {
                        let articlesLinks = `
                            <p><a href=${article.html_url}>${article.title}</a></p>
                        `;
                        content.insertAdjacentHTML('afterbegin', articlesLinks)
                    })

                    dynamicTitle.innerHTML = 'DÚVIDAS FREQUENTES'
                    dynamicContent.classList.remove('change-content')
                }, 700)

            })

            openTicketBtn.addEventListener('click', () => {
                dynamicContent.classList.add('change-content')

                setTimeout(() => {
                    content.innerHTML = ''
                    let contentSAC = `
                        <br><br><h3>(11) 4130-8933</h3>
                        <h6>São Paulo Capital</h6>

                        <h3>4003-1627</h3>
                        <h6>Capitais e Regiões Metropolitanas</h6>

                        <h3>0800-550-0333</h3>
                        <h6>Outras Regiões</h6>
                    `;

                    content.insertAdjacentHTML('afterbegin', contentSAC)

                    dynamicTitle.innerHTML = 'FALE CONOSCO'
                    dynamicContent.classList.remove('change-content')
                }, 700)
            })
        })
    }

    getArticles()

    //botão suas joias 
    ourJewelArticles.addEventListener('click', () => {

        dynamicContent.classList.add('change-content')

        setTimeout(() => {
            content.innerHTML = '';
            let articles = `
            <p><a href="https://pandorabrasil.zendesk.com/hc/pt-br/articles/27680783069203-Esmalte">Esmalte</a></p>
            <p><a href="https://pandorabrasil.zendesk.com/hc/pt-br/articles/27680735086995-Couro">Couro</a></p>
            <p><a href="https://pandorabrasil.zendesk.com/hc/pt-br/articles/27680729598995-Cordões-coloridos">Cordões coloridos</a></p>
            <p><a href="https://pandorabrasil.zendesk.com/hc/pt-br/articles/27680704414867-Coleção-Pandora-Essence">Coleção Pandora Essence</a></p>
            <p><a href="https://pandorabrasil.zendesk.com/hc/pt-br/articles/27680569021843-O-tamanho-perfeito-do-seu-bracelete">O tamanho perfeito do seu bracelete</a></p>
            <p><a href="https://pandorabrasil.zendesk.com/hc/pt-br/articles/27680591547539-Como-cuidar-das-suas-joias">Como cuidar das suas joias</a></p>
            <p><a href="https://pandorabrasil.zendesk.com/hc/pt-br/articles/27680551845779-Bracelestes">Braceletes</a></p>
            <p><a href="https://pandorabrasil.zendesk.com/hc/pt-br/articles/27680562707859-Como-posso-saber-a-medida-do-meu-anel">Como posso saber a medida do meu anel?</a></p>
            <p><a href="https://pandorabrasil.zendesk.com/hc/pt-br/articles/27680506769043-Armazenamento-das-suas-joias">Armazenamento</a></p>
            <p><a href="https://pandorabrasil.zendesk.com/hc/pt-br/articles/27680494645779-As-jois-da-Pandora-são-originais">As joias da Pandora são originais?</a></p>
            `;
            content.insertAdjacentHTML('afterbegin', articles);
            dynamicTitle.innerHTML = 'NOSSAS JOIAS';
            dynamicContent.classList.remove('change-content')
        }, 700)
    })

    regulationsArticles.addEventListener('click', () => {
        const urlSite = 'https://www.pandorajoias.com.br/institucional/regulamentos';
        window.location.href = urlSite;
    });
}


//removendo campo de seleção de formulários de solicitação no form principal
if (window.location.href === 'https://pandorabrasil.zendesk.com/hc/pt-br/requests/new?ticket_form_id=1900000679725') {
    const requestFieldFormId = document.querySelector('.request_ticket_form_id');
    requestFieldFormId.classList.add('deleted-field-form')
}